/*
@licstart  The following is the entire license notice for the
JavaScript code in this file.

Copyright (C) 1997-2019 by Dimitri van Heesch

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as published by
the Free Software Foundation

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

@licend  The above is the entire license notice
for the JavaScript code in this file
*/
var menudata={children:[
{text:"Page principale",url:"index.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Liste des classes",url:"annotated.html"},
{text:"Index des classes",url:"classes.html"},
{text:"Membres de classe",url:"functions.html",children:[
{text:"Tout",url:"functions.html"},
{text:"Fonctions",url:"functions_func.html"},
{text:"Variables",url:"functions_vars.html"}]}]},
{text:"Fichiers",url:"files.html",children:[
{text:"Liste des fichiers",url:"files.html"},
{text:"Membres de fichier",url:"globals.html",children:[
{text:"Tout",url:"globals.html"},
{text:"Fonctions",url:"globals_func.html"}]}]}]}
