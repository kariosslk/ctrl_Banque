var indexSectionsWithContent =
{
  0: "acdelmnors~",
  1: "cem",
  2: "cm",
  3: "acdemor~",
  4: "clmnos"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables"
};

