var class_exception =
[
    [ "Exception", "class_exception.html#a283c77c5196279d4190cff644722babd", null ],
    [ "ObtenirCodeErreur", "class_exception.html#a5959862a5c9a2c2a0ef9f51cd1e91c36", null ],
    [ "ObtenirMessage", "class_exception.html#a75a61c52bbe35fe208ddb9eb4a15a151", null ],
    [ "code", "class_exception.html#a9a71c9fe2c765fc8dd0f7e97a20b636b", null ],
    [ "message", "class_exception.html#a80bf622a8fc3c48fa6ab1a3fc024ff91", null ]
];