var searchData=
[
  ['obtenircodeerreur_55',['ObtenirCodeErreur',['../class_exception.html#a5959862a5c9a2c2a0ef9f51cd1e91c36',1,'Exception']]],
  ['obtenirmessage_56',['ObtenirMessage',['../class_exception.html#a75a61c52bbe35fe208ddb9eb4a15a151',1,'Exception']]]
];
